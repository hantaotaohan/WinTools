from __future__ import (unicode_literals, division, absolute_import, print_function)


'''
from .python_transition import (IS_PYTHON2, bytes_, bytes_indexed, bytes_to_hex, bytes_to_list)
if IS_PYTHON2:
    urllib
    from .python_transition import (bytes, chr, repr, str, urllib)
'''


import sys


IS_PYTHON2 = sys.version_info[0] == 2

if IS_PYTHON2:

    from urllib import (quote, quote_plus, unquote, urlencode)
    from urllib2 import (build_opener, HTTPCookieProcessor, HTTPError, HTTPHandler, HTTPSHandler, Request)
    from urlparse import (parse_qs, urljoin, urlparse)

    class Object(object):
        pass

    parse = Object()
    parse.parse_qs = parse_qs
    parse.quote = quote
    parse.quote_plus = quote_plus
    parse.unquote = unquote
    parse.urlencode = urlencode
    parse.urljoin = urljoin
    parse.urlparse = urlparse

    request = Object()
    request.build_opener = build_opener
    request.HTTPCookieProcessor = HTTPCookieProcessor
    request.HTTPError = HTTPError
    request.HTTPHandler = HTTPHandler
    request.HTTPSHandler = HTTPSHandler
    request.Request = Request

    urllib = Object()
    urllib.parse = parse
    urllib.request = request

    try:
        unicode
        unichr
    except NameError:
        unicode = unichr = None

    py2_chr = chr
    bytes = str
    str = unicode
    chr = unichr

    def repr(obj):
        return obj.__repr__()

    class bytes_(bytes):
        def __new__(cls, x):
            if isinstance(x, bytes):
                return x

            if isinstance(x, int):
                return b"\x00" * x

            if isinstance(x, list):
                return b"".join(py2_chr(i) for i in x)

            raise TypeError("Cannot convert %s to bytes" % type(x).__name__)

        @staticmethod
        def fromhex(s):
            if not isinstance(s, str):
                raise TypeError("fromhex %s" % type(s).__name__)

            return s.decode("hex")

    def bytes_indexed(b, i):
        if not isinstance(b, bytes):
            raise TypeError("bytes_indexed %s" % type(b).__name__)

        return ord(b[i])

    def bytes_to_hex(b):
        if not isinstance(b, bytes):
            raise TypeError("bytes_to_hex %s" % type(b).__name__)

        return b.encode("hex").decode("ascii")

    def bytes_to_list(b):
        if not isinstance(b, bytes):
            raise TypeError("bytes_to_list %s" % type(b).__name__)

        return [ord(c) for c in list(b)]

else:

    bytes_ = bytes

    def bytes_indexed(b, i):
        return b[i]

    def bytes_to_hex(b):
        return b.hex()

    def bytes_to_list(data):
        return list(data)
